const xrpl = require('xrpl')

async function main() {
    const client = new xrpl.Client("wss://s.altnet.rippletest.net:51233")
    await client.connect()

    const test_wallet = xrpl.Wallet.fromSeed("sEdTDrA92JzRNCg1EjsZCBjn5MXiWqB")
    console.log(test_wallet.address) 

    const response = await client.request({
        "command": "account_info",
        "account": test_wallet.address,
        "ledger_index": "validated"
    })
    console.log(response)

    client.request({
        "command": "subscribe",
        "streams": ["ledger"]
    })
    client.on("ledgerClosed", async (ledger) => {
        console.log(`Ledger #${ledger.ledger_index} validated with ${ledger.txn_count} transactions!`)
    })

    // [1] -> [2]
    const prepared = await client.autofill({
        "TransactionType": "Payment",
        "Account": test_wallet.address, // Change here
        "Amount": xrpl.xrpToDrops(10),
        "Destination": "r4UcZSU1UxiPDQ36453kkipBN3E1DDp3uq"
    }, 10)
    const max_ledger = prepared.LastLedgerSequence
    console.log("Prepared transaction instructions:", prepared)
    console.log("Transaction cost:", xrpl.dropsToXrp(prepared.Fee), "XRP")
    console.log("Transaction expires after ledger:", max_ledger)

    const signed = test_wallet.sign(prepared)
    console.log("Identifying hash:", signed.hash)
    console.log("Signed blob:", signed.tx_blob)

    const tx = await client.submitAndWait(signed.tx_blob)

    console.log("Transaction result:", tx.result.meta.TransactionResult)
    console.log("Balance changes:", JSON.stringify(xrpl.getBalanceChanges(tx.result.meta), null, 2))

    client.disconnect()
}

main()
